const form = document.querySelector("#sort-form");
const numbersInput = document.querySelector("#numbers");
const algorithmInput = document.querySelector("#algorithm");
const orderInput = document.querySelector("#order");
const message = document.querySelector("#message");
const originalList = document.querySelector("#original-list");
const sortedList = document.querySelector("#sorted-list");
const itemCount = document.querySelector("#item-count");
const orderLabel = document.querySelector("#order-label");
const sortedDescription = document.querySelector("#sorted-description");
const resultStatus = document.querySelector("#result-status");
const comparisonsOutput = document.querySelector("#comparisons");
const swapsOutput = document.querySelector("#swaps");
const algorithmUsed = document.querySelector("#algorithm-used");
const traceList = document.querySelector("#trace-list");
const stepCount = document.querySelector("#step-count");
const showMoreButton = document.querySelector("#show-more");

const MAX_VALUES = 100;
const INITIAL_TRACE_LIMIT = 12;
let allTraceSteps = [];
let expandedTrace = false;

function parseNumbers(raw) {
  const cleaned = raw.trim();
  if (!cleaned) {
    throw new Error("Digite pelo menos um número para começar.");
  }

  const parts = cleaned.split(/[,\s;]+/).filter(Boolean);
  if (parts.length > MAX_VALUES) {
    throw new Error(`Digite no máximo ${MAX_VALUES} números por vez.`);
  }

  const values = [];
  for (const part of parts) {
    const value = Number(part);
    if (part === "" || !Number.isFinite(value)) {
      throw new Error(`O valor "${part}" não é válido. Use apenas números separados por vírgulas ou espaços.`);
    }
    values.push(value);
  }
  return values;
}

function shouldSwap(left, right, order) {
  return order === "asc" ? left > right : left < right;
}

function bubbleSort(input, order) {
  const values = input.slice();
  const steps = [];
  let comparisons = 0;
  let swaps = 0;

  for (let end = values.length - 1; end > 0; end--) {
    let changed = false;
    for (let i = 0; i < end; i++) {
      comparisons++;
      const left = values[i];
      const right = values[i + 1];
      if (shouldSwap(left, right, order)) {
        values[i] = right;
        values[i + 1] = left;
        swaps++;
        changed = true;
        steps.push({
          type: "swap",
          text: `Comparou ${formatNumber(left)} e ${formatNumber(right)}: trocou os valores vizinhos.`,
          values: values.slice()
        });
      } else {
        steps.push({
          type: "compare",
          text: `Comparou ${formatNumber(left)} e ${formatNumber(right)}: a ordem está correta, não precisou trocar.`,
          values: values.slice()
        });
      }
    }
    if (!changed) break;
  }
  return { values, steps, comparisons, swaps };
}

function selectionSort(input, order) {
  const values = input.slice();
  const steps = [];
  let comparisons = 0;
  let swaps = 0;

  for (let i = 0; i < values.length - 1; i++) {
    let selected = i;
    for (let j = i + 1; j < values.length; j++) {
      comparisons++;
      steps.push({
        type: "compare",
        text: `Comparou ${formatNumber(values[selected])} com ${formatNumber(values[j])} para encontrar o próximo valor da sequência.`,
        values: values.slice()
      });
      const better = order === "asc" ? values[j] < values[selected] : values[j] > values[selected];
      if (better) selected = j;
    }

    if (selected !== i) {
      const first = values[i];
      values[i] = values[selected];
      values[selected] = first;
      swaps++;
      steps.push({
        type: "swap",
        text: `Colocou ${formatNumber(values[i])} na posição ${i + 1}, trocando com ${formatNumber(first)}.`,
        values: values.slice()
      });
    } else {
      steps.push({
        type: "place",
        text: `${formatNumber(values[i])} já estava na posição correta.`,
        values: values.slice()
      });
    }
  }
  return { values, steps, comparisons, swaps };
}

function formatNumber(value) {
  return Object.is(value, -0) ? "0" : String(value);
}

function renderNumbers(container, values) {
  container.replaceChildren();
  container.classList.toggle("empty-list", values.length === 0);
  for (const value of values) {
    const chip = document.createElement("span");
    chip.className = "number-chip";
    chip.textContent = formatNumber(value);
    container.appendChild(chip);
  }
}

function renderTrace() {
  traceList.replaceChildren();
  const visibleSteps = expandedTrace ? allTraceSteps : allTraceSteps.slice(0, INITIAL_TRACE_LIMIT);

  if (visibleSteps.length === 0) {
    const empty = document.createElement("li");
    empty.className = "trace-empty";
    empty.textContent = "Nenhuma comparação foi necessária para esta sequência.";
    traceList.appendChild(empty);
  } else {
    visibleSteps.forEach((step, index) => {
      const item = document.createElement("li");
      const indexBadge = document.createElement("span");
      indexBadge.className = "trace-index";
      indexBadge.textContent = String(index + 1).padStart(2, "0");

      const detail = document.createElement("div");
      detail.className = "trace-detail";
      const strong = document.createElement("strong");
      strong.textContent = step.type === "swap" ? "Troca · " : step.type === "place" ? "Posição · " : "Comparação · ";
      const text = document.createElement("span");
      text.textContent = step.text;
      if (step.type === "swap") text.className = "swap-label";
      detail.append(strong, text);
      item.append(indexBadge, detail);
      traceList.appendChild(item);
    });
  }

  stepCount.textContent = `${allTraceSteps.length} ${allTraceSteps.length === 1 ? "etapa" : "etapas"}`;
  showMoreButton.hidden = allTraceSteps.length <= INITIAL_TRACE_LIMIT;
  showMoreButton.textContent = expandedTrace ? "Mostrar menos etapas" : "Mostrar todas as etapas";
}

function resetResults() {
  originalList.textContent = "Sua lista aparecerá aqui.";
  sortedList.textContent = "Pronto para ordenar.";
  originalList.classList.add("empty-list");
  sortedList.classList.add("empty-list");
  itemCount.textContent = "—";
  orderLabel.textContent = "—";
  sortedDescription.textContent = "O resultado aparecerá aqui.";
  resultStatus.textContent = "Aguardando sua sequência";
  comparisonsOutput.textContent = "—";
  swapsOutput.textContent = "—";
  algorithmUsed.textContent = "—";
  allTraceSteps = [];
  expandedTrace = false;
  renderTrace();
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  message.textContent = "";

  let inputValues;
  try {
    inputValues = parseNumbers(numbersInput.value);
  } catch (error) {
    message.textContent = error.message;
    resultStatus.textContent = "Verifique a entrada";
    return;
  }

  const order = orderInput.value;
  const algorithm = algorithmInput.value;
  const result = algorithm === "bubble"
    ? bubbleSort(inputValues, order)
    : selectionSort(inputValues, order);

  renderNumbers(originalList, inputValues);
  renderNumbers(sortedList, result.values);
  itemCount.textContent = String(inputValues.length);
  orderLabel.textContent = order === "asc" ? "Crescente" : "Decrescente";
  sortedDescription.textContent = order === "asc" ? "Do menor para o maior." : "Do maior para o menor.";
  resultStatus.textContent = "Ordenação concluída";
  comparisonsOutput.textContent = String(result.comparisons);
  swapsOutput.textContent = String(result.swaps);
  algorithmUsed.textContent = algorithm === "bubble" ? "Bubble Sort" : "Selection Sort";
  allTraceSteps = result.steps;
  expandedTrace = false;
  renderTrace();
});

document.querySelector("#example-button").addEventListener("click", () => {
  numbersInput.value = "8, 3, 10, -2, 3, 1";
  message.textContent = "";
  numbersInput.focus();
});

document.querySelector("#clear-button").addEventListener("click", () => {
  numbersInput.value = "";
  message.textContent = "";
  resetResults();
  numbersInput.focus();
});

showMoreButton.addEventListener("click", () => {
  expandedTrace = !expandedTrace;
  renderTrace();
});

resetResults();
